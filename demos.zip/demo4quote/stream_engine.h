#pragma once

#include "snap_task.h"
#include "redis_hub.h"
#include "stream_engine_define.h"

class EngineInterface
{
public:
    virtual void on_snap(const string& exchange, const string& symbol) = 0;
    virtual void on_update(const string& exchange, const string& symbol) = 0;
};


class StreamEngine : public EngineInterface 
{
public:
    using TMarketQuotePtr = boost::shared_ptr<unordered_map<string, string>>;
    using TRedisHubPtr = boost::shared_ptr<RedisHub>;
public:
    StreamEngine(){
        string exchangeToSubscribe = "XDAEX";
        //if( argc >= 2 ) {
        //    exchangeToSubscribe = argv[1];
        //}
        cout << "subscribe exchange:" << exchangeToSubscribe << endl;

        redis_hub_ = boost::make_shared<TRedisHubPtr>("45.249.244.59", 6666, "rkqFB4,wpoMmHqT6he}r");
        redis_hub_->Subscribe("EOS_USDT", "XDAEX");
        //market_dispatcher_->SubscribeByExchange(exchangeToSubscribe);
        //market_dispatcher_->SubscribeAll();
    }

    ~StreamEngine(){}

    void start() {
        snap_task_->start();
        redis_hub_->start();
    }

    void on_snap(const string& exchange, const string& symbol){};
    void on_update(const string& exchange, const string& symbol){};

private:
    std::mutex                              mutex_markets_;
    unordered_map<string, TMarketQuotePtr> markets_;

    // symbol center
    SnapTaskCenter    snap_task_;

    // redis upstream
    TRedisHubPtr   redis_hub_;
}
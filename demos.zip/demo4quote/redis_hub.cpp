#pragma once

#include "redis_hub.h"
#include "stream_engine.h"


void RedisHub::OnMessage(const std::string& channel, const std::string& msg){
    cout << "\nReceive Msg: " << channel << " Msg: " << msg << "\n" << endl;
    // all channel
    if( all_channels_.find(channel) == all_channels_.end() ) {
        all_channels_[channel] = 1;
        cout << "find new channel:" << channel << endl;
    } else {
        all_channels_[channel] += 1;
    }
};
#pragma once

#include <string>
#include <unordered_map>
using namespace std;
typedef string TMarket;
typedef string TSymbol;
typedef string TQuoteData;


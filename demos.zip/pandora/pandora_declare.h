#pragma once
#include "envdeclare.h"

#include <unordered_map>

#define PANDORA_NAMESPACE_START namespace utrade { namespace pandora {
#define PANDORA_NAMESPACE_END }}
#define USING_PANDORA_NAMESPACE using namespace utrade::pandora;
